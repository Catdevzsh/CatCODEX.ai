"""The plugin system allows the Agent to be extended with new functionality."""
from autogpt.core.plugin.base import PluginService
